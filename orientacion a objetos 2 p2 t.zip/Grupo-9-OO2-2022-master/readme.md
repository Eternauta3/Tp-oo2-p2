# Grupo 9 - UnlaGestionAulas2022
Proyecto 2022 SpringBoot App

## Grupo 9: Diego Olmedo, Patricio Arango, Enzo Valenzuela, Walter Altamiranda y Albarracín

## Instalación
El proyecto funciona en http://localhost:8080<br>
El script de base de datos se encuentra en la raíz del proyecto Grupo-9-BDD-OO2-2022.sql<br>
## Usuarios
# Administrador:
usuario: admin<br>
contraseña: admin<br>

# Auditor
usuario: auditor<br>
contraseña: auditor<br>
