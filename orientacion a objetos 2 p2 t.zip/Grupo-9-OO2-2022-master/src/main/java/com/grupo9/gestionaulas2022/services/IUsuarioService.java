package com.grupo9.gestionaulas2022.services;

import java.util.List;

import com.grupo9.gestionaulas2022.entities.Usuario;
import com.grupo9.gestionaulas2022.models.UsuarioModel;

public interface IUsuarioService {

	public List<UsuarioModel> getAll();
	
	public Usuario findById(long id);
	
	public List<UsuarioModel> getAllEnabled();
		
	public UsuarioModel updateUser(UsuarioModel userModel);

	public UsuarioModel traerUsuarioYPerfilPorId(long id);

	public UsuarioModel traerUsuarioYPerfilPorUsername(String username);

}
