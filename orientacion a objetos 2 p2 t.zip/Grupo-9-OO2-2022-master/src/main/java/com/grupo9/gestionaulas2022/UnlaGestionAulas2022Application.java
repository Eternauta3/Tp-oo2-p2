package com.grupo9.gestionaulas2022;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnlaGestionAulas2022Application {

	public static void main(String[] args) {
		SpringApplication.run(UnlaGestionAulas2022Application.class, args);
	}

}
