package com.grupo9.gestionaulas2022.services;

import java.util.List;

import com.grupo9.gestionaulas2022.entities.Edificio;
import com.grupo9.gestionaulas2022.models.EdificioModel;

public interface IEdificioService {

	public List<EdificioModel> getAll();
	
	public Edificio findById(long id);
	
	public List<EdificioModel> getAllEnabled();
		
	public EdificioModel updateUser(EdificioModel userModel);

	public EdificioModel traerUsuarioYPerfilPorId(long idedi);
	
}
