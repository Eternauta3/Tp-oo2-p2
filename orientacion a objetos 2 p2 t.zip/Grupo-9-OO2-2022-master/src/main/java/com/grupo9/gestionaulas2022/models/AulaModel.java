package com.grupo9.gestionaulas2022.models;

public class AulaModel {
//__________
	private int id;
	private int numero;
	private EdificioModel edificio;
	private boolean enabled;
//__________
	public AulaModel(int numero,EdificioModel edificio,boolean enabled) {
	super();
	this.setId(id);
	this.setNumero(getNumero());
	this.setEdificio(edificio);
	this.setEnabled(enabled);
}
//__________
public int getId() {
return id;
}
protected void setId(int id) {
this.id = id;
}
public int getNumero() {
return numero;
}
public void setNumero(int numero) {
this.numero = numero;
}
public EdificioModel getEdificio() {
return edificio;
}
public void setEdificio(EdificioModel edificio) {
this.edificio = edificio;
}
public boolean isEnabled() {
	return enabled;
}
public void setEnabled(boolean enabled) {
	this.enabled = enabled;
}
//__________
@Override
public String toString() {
	return "AulaModel [id=" + id + ", numero=" + numero + ", edificio=" + edificio + ", enabled=" + enabled;
}

}
