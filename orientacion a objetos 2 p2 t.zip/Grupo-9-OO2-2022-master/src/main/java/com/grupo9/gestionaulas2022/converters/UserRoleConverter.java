package com.grupo9.gestionaulas2022.converters;

import org.springframework.stereotype.Component;

import com.grupo9.gestionaulas2022.entities.UserRole;
import com.grupo9.gestionaulas2022.models.UserRoleModel;

@Component
public class UserRoleConverter {
	
	public UserRoleModel entityToModel(UserRole rol) {
		return new UserRoleModel(rol.getId(),rol.getRole(),rol.isEnabled());
	}

	public UserRole modeltoEntity(UserRoleModel rol) {
		return new UserRole(rol.getId(),rol.getRole(),rol.isEnabled());
	}
}