package com.grupo9.gestionaulas2022.entities;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "edificio")
public class Edificio {
//_______________________________________________
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int idedi;

@Column(name = "edificio")
private String edificio;

@Column(name = "aulas")
private Set<Aula> aulas;

//_______________________________________________
public Edificio(String edificio) {
	super();
	this.setIdedi(idedi);
	this.setEdificio(edificio);
	this.setAulas(aulas);
}
//_______________________________________________


public int getIdedi() {
	return idedi;
}

protected void setIdedi(int idedi) {
	this.idedi = idedi;
}

public String getEdificio() {
	return edificio;
}

public void setEdificio(String edificio) {
	this.edificio = edificio;
}

public Set<Aula> getAulas() {
	return aulas;
}

public void setAulas(Set<Aula> aulas) {
	this.aulas = aulas;
}
//_______________________________________________
}
