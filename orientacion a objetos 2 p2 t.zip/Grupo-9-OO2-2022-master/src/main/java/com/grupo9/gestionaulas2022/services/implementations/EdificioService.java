package com.grupo9.gestionaulas2022.services.implementations;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.grupo9.gestionaulas2022.converters.EdificioConverter;
import com.grupo9.gestionaulas2022.entities.Edificio;
import com.grupo9.gestionaulas2022.models.EdificioModel;
import com.grupo9.gestionaulas2022.repositories.IEdificioRepository;

@Service("aulaService")
public class EdificioService {
@Autowired 
private IEdificioRepository edificioRepo;

@Autowired
private EdificioConverter edifConverter;

public EdificioModel traerEdificio(long idedi) {
	EdificioModel edificio = edifConverter.entityToModel(edificioRepo.findById(idedi));
	return edificio;
}

public List<EdificioModel> TraerEdificio() {
	List<EdificioModel> edificio = new ArrayList<>();
	for(Edificio u : edificioRepo.findAll()){
		edificio.add(edifConverter.entityToModel(u));
	}
	return edificio;
}
}
