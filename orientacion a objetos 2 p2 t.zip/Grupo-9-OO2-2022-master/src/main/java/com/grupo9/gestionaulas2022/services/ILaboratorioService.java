package com.grupo9.gestionaulas2022.services;

import java.util.List;

import com.grupo9.gestionaulas2022.entities.Laboratorio;
import com.grupo9.gestionaulas2022.models.LaboratorioModel;

public interface ILaboratorioService {
	public List<LaboratorioModel> getAll();
	
	public Laboratorio findById(long id);
	
	public List<LaboratorioModel> getAllEnabled(int enabled);
		
	public LaboratorioModel updateRol(LaboratorioModel rol);
}
