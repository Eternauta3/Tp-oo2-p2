package com.grupo9.gestionaulas2022.converters;

import org.springframework.stereotype.Component;

import com.grupo9.gestionaulas2022.entities.Aula;
import com.grupo9.gestionaulas2022.models.AulaModel;

@Component
public class AulaConverter {
	
	public AulaModel entityToModel(Aula aula) {
		return new AulaModel(aula.getNumero(),null,aula.isEnabled());
	}

	public Aula modeltoEntity(AulaModel aula) {
		return new Aula(aula.getId(),null,aula.isEnabled());
	}
}
