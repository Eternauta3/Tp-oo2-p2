package com.grupo9.gestionaulas2022.models;

public class LaboratorioModel extends AulaModel{
//__________
	private int cantPc;
	private int cantSillas;
//__________
	public LaboratorioModel(int numero, EdificioModel edificio, boolean enabled, int cantPc,int cantSillas) {
		super(numero, edificio, enabled);
this.setCantPc(cantPc);
this.setCantSillas(cantSillas);
	}	
//__________
	public int getCantPc() {
		return cantPc;
	}
	public void setCantPc(int cantPc) {
		this.cantPc = cantPc;
	}
	public int getCantSillas() {
		return cantSillas;
	}
	public void setCantSillas(int cantSillas) {
		this.cantSillas = cantSillas;
	}
//__________
	@Override
	public String toString() {
		return "LaboratorioModel [toString()=" + super.toString() + ", cantPc=" + cantPc + ", cantSillas=" + cantSillas
				+ "]";
	}
	
//__________
}
