package com.grupo9.gestionaulas2022.converters;

import com.grupo9.gestionaulas2022.entities.Laboratorio;
import com.grupo9.gestionaulas2022.models.LaboratorioModel;


public class LaboratorioConverter {
public LaboratorioModel entityToModel(Laboratorio labo) {
return new LaboratorioModel(labo.getNumero(),null,labo.isEnabled(),labo.getCantPc(),labo.getCantSillas());
}

public Laboratorio modeltoEntity(LaboratorioModel labo) {
return new Laboratorio(labo.getId(),labo.getNumero(),null,labo.isEnabled(),labo.getCantPc(),labo.getCantSillas());
}
}
