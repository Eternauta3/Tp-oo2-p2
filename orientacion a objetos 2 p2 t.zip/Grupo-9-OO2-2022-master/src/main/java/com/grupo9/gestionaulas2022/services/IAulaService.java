package com.grupo9.gestionaulas2022.services;

import java.util.List;

import com.grupo9.gestionaulas2022.entities.Aula;
import com.grupo9.gestionaulas2022.models.AulaModel;

public interface IAulaService {
	public List<AulaModel> getAll();
	
	public Aula findById(long id);
	
	public List<AulaModel> getAllEnabled(int enabled);
		
	public AulaModel updateRol(AulaModel rol);
}
