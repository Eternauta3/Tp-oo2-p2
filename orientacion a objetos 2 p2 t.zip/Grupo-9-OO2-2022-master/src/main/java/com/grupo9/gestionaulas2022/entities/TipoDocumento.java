package com.grupo9.gestionaulas2022.entities;


public enum TipoDocumento {
	    DNI,
	    PASAPORTE,
	    CUIT
}
