CREATE DATABASE UnlaGestionAulas;

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdat` datetime DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `role` varchar(100) NOT NULL,
  `updatedat` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `user_role` */

insert  into `user_role`(`id`,`createdat`,`enabled`,`role`,`updatedat`) values (1,'2021-05-19 12:31:00','','ADMINISTRADOR','2021-05-19 12:31:00'),(2,'2021-05-19 12:31:00','','AUDITOR','2021-05-19 12:31:00');

	DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `apellido` varchar(50) NOT NULL,
  `createdat` datetime DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `nombre` varchar(50) NOT NULL,
  `nro_documento` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tipo_documento` varchar(255) DEFAULT NULL,
  `updatedat` datetime DEFAULT NULL,
  `username` varchar(15) NOT NULL,
  `id_rol` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
  
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`id`,`apellido`,`createdat`,`email`,`enabled`,`nombre`,`nro_documento`,`password`,`tipo_documento`,`updatedat`,`username`,`id_rol`) values (4,'auditor','2021-06-06 23:42:09','unla23@unla.com','','Auditor','2011923423','$2a$10$/uTY/65SEf.l55NIVXwKuevLvzIBph3oLPu8768m5Os6BT/SCiRl.','DNI','2021-06-06 23:42:09','auditor',2),(5,'Arango','2021-06-06 23:38:25','pato.sg2@gmail.com','','Patricio','29119499','$2a$10$u9YluwmwzdmZhRP0hL0VXOE8mw..h188cj9kuuz2rJTD3/JIXvxaK','DNI','2021-06-06 23:38:25','admin',1);