package com.grupo9.gestionaulas2022.repositories;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.grupo9.gestionaulas2022.entities.Aula;

@Repository
public interface IAulaRepository {
	public Aula findById(long id);
	public List<Aula> findAllByEnabledTrue();
	public List<Aula> findAll();
}
