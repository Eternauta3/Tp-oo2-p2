package com.grupo9.gestionaulas2022.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tradicional")
public class Tradicional extends Aula{
//_______________________________________________
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;

@Column(name = "numero", unique = true, nullable = false)
private int numero;

@Column(name = "edificio")
private Edificio edificio;

@Column(name = "enabled")
private boolean enabled;

@Column(name = "cantbancos")
private int cantBancos;

@Column(name = "pizarron", length = 50)
private String pizarron;

@Column(name = "tieneproyector", length = 50)
private boolean tieneProyector;

public Tradicional() {}
//_______________________________________________

public Tradicional(int numero, Edificio edificio, boolean enabled,int cantBancos,String pizarron,boolean tieneProyector) {
	super(numero, edificio, enabled);
	// TODO Auto-generated constructor stub
this.setCantBancos(cantBancos);
this.setPizarron(pizarron);
this.setTieneProyector(tieneProyector);
}

//_______________________________________________
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public int getNumero() {
	return numero;
}

public void setNumero(int numero) {
	this.numero = numero;
}

public Edificio getEdificio() {
	return edificio;
}

public void setEdificio(Edificio edificio) {
	this.edificio = edificio;
}

public boolean isEnabled() {
	return enabled;
}

public void setEnabled(boolean enabled) {
	this.enabled = enabled;
}

public int getCantBancos() {
	return cantBancos;
}

public void setCantBancos(int cantBancos) {
	this.cantBancos = cantBancos;
}

public String getPizarron() {
	return pizarron;
}

public void setPizarron(String pizarron) {
	this.pizarron = pizarron;
}

public boolean isTieneProyector() {
	return tieneProyector;
}

public void setTieneProyector(boolean tieneProyector) {
	this.tieneProyector = tieneProyector;
}
//__________
@Override
public String toString() {
	return "Tradicional [id=" + id + ", numero=" + numero + ", edificio=" + edificio + ", enabled=" + enabled
			+ ", cantBancos=" + cantBancos + ", pizarron=" + pizarron + ", tieneProyector=" + tieneProyector + "]";
}
//__________
}