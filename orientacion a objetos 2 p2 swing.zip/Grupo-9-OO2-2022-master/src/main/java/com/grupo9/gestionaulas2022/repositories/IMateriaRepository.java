package com.grupo9.gestionaulas2022.repositories;

import java.util.List;

import com.grupo9.gestionaulas2022.entities.Materia;

public interface IMateriaRepository {
	public Materia findById(long id);
	public List<Materia> findAllByEnabledTrue();
	public List<Materia> findAll();
}
