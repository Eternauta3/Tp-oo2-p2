package com.grupo9.gestionaulas2022.models;

import com.grupo9.gestionaulas2022.entities.Departamento;

public class CarreraModel {
//__________________
private int id;
private String carrera;
private Departamento departamento;
//__________________	
public CarreraModel(int id, String carrera, Departamento departamento) {
	super();
this.setId(id);
this.setCarrera(carrera);
this.setDepartamento(departamento);
}
//__________________
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}
public String getCarrera() {
	return carrera;
}
public void setCarrera(String carrera) {
	this.carrera = carrera;
}
public Departamento getDepartamento() {
	return departamento;
}
public void setDepartamento(Departamento departamento) {
	this.departamento = departamento;
}
//__________________	
@Override
public String toString() {
	return "CarreraModel [id=" + id + ", carrera=" + carrera + ", departamento=" + departamento + "]";
}
//__________________	
}
