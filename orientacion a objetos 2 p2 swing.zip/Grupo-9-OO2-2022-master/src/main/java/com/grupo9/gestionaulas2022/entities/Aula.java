package com.grupo9.gestionaulas2022.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "aula")
public abstract class Aula {
//________________________________________________
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;
	
@Column(name = "numero", unique = true, nullable = false)
private int numero;

@Column(name = "edificio")
private Edificio edificio;

@Column(name = "enabled")
private boolean enabled;

public Aula() {}
//_________________________________________________

public Aula(int numero, Edificio edificio, boolean enabled) {
	super();
	this.setId(id);
	this.setNumero(numero);
	this.setEdificio(edificio);
	this.setEnabled(enabled);
}
//_________________________________________________

public int getId() {
	return id;
}

protected void setId(int id) {
	this.id = id;
}

public int getNumero() {
	return numero;
}

public void setNumero(int numero) {
	this.numero = numero;
}

public boolean isEnabled() {
	return enabled;
}

public void setEnabled(boolean enabled) {
	this.enabled = enabled;
}

public Edificio getEdificio() {
	return edificio;
}

public void setEdificio(Edificio edificio) {
	this.edificio = edificio;
}


//_________________________________________________
}
