package com.grupo9.gestionaulas2022.repositories;

import java.util.List;

import com.grupo9.gestionaulas2022.entities.Edificio;

public interface IEdificioRepository {
	public Edificio findById(long idedi);
	public List<Edificio> findAllByEnabledTrue();
	public List<Edificio> findAll();
}
