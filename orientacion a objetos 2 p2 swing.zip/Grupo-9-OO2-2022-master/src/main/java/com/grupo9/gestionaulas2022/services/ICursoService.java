package com.grupo9.gestionaulas2022.services;

import java.util.List;

import com.grupo9.gestionaulas2022.entities.Curso;
import com.grupo9.gestionaulas2022.models.AulaModel;
import com.grupo9.gestionaulas2022.models.CursoModel;

public interface ICursoService {
	public List<CursoModel> getAll();
	
	public Curso findById(long id);
	
	public List<CursoModel> getAllEnabled(int enabled);
		
	public CursoModel updateRol(AulaModel rol);
}
