package com.grupo9.gestionaulas2022.entities;

public class Departamento {
//________
private int id;
private String departamento;
//________
public Departamento(int id, String departamento) {
	super();
	this.setId(id);
	this.setDepartamento(departamento);
}
//________
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}
public String getDepartamento() {
	return departamento;
}
public void setDepartamento(String departamento) {
	this.departamento = departamento;
}
//________
}
