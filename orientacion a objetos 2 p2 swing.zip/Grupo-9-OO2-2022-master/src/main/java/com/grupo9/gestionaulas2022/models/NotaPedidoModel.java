package com.grupo9.gestionaulas2022.models;

import java.time.LocalDate;

import com.grupo9.gestionaulas2022.entities.Aula;
import com.grupo9.gestionaulas2022.entities.Materia;

public class NotaPedidoModel {
//________
private int id;
private LocalDate fecha;
private char turno;
private Aula aula;
private int cantEstudiantes;
private Materia materia;
private String observaciones;
//________
public NotaPedidoModel(int id, LocalDate fecha, char turno, Aula aula, int cantEstudiantes, Materia materia,
		String observaciones) {
	super();
this.setId(id);
this.setFecha(fecha);
this.setTurno(turno);
this.setAula(getAula());
this.setCantEstuduantes(cantEstudiantes);
this.setMateria(materia);
this.setObservaciones(observaciones);
}
//________
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}
public LocalDate getFecha() {
	return fecha;
}
public void setFecha(LocalDate fecha) {
	this.fecha = fecha;
}
public char getTurno() {
	return turno;
}
public void setTurno(char turno) {
	this.turno = turno;
}
public Aula getAula() {
	return aula;
}
public void setAula(Aula aula) {
	this.aula = aula;
}
public int getCantEstudiantes() {
	return cantEstudiantes;
}
public void setCantEstuduantes(int cantEstudiantes) {
	this.cantEstudiantes = cantEstudiantes;
}
public Materia getMateria() {
	return materia;
}
public void setMateria(Materia materia) {
	this.materia = materia;
}
public String getObservaciones() {
	return observaciones;
}
public void setObservaciones(String observaciones) {
	this.observaciones = observaciones;
}
//________

}
