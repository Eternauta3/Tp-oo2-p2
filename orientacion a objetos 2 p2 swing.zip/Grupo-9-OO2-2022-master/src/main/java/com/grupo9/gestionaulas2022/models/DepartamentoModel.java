package com.grupo9.gestionaulas2022.models;

public class DepartamentoModel {
//__________________
private int id;
private String departamento;
//__________________
public DepartamentoModel(int id, String departamento) {
	super();
this.setId(id);
this.setDepartamento(departamento);
}
//__________________
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}
public String getDepartamento() {
	return departamento;
}
public void setDepartamento(String departamento) {
	this.departamento = departamento;
}
//__________________
}
