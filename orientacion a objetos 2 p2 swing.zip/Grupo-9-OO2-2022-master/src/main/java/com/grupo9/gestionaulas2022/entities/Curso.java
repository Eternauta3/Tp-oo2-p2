package com.grupo9.gestionaulas2022.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "carrera")
public class Curso  extends NotaPedido{
//_______________
@Column(name = "codcurso", unique = true)
private String codCurso;
//_______________
public Curso(int id, LocalDate fecha, char turno, Aula aula, int cantEstudiantes, Materia materia,
		String observaciones,String codCurso) {
	super(id, fecha, turno,aula, cantEstudiantes, materia, observaciones);
this.setCodCurso(codCurso);
}
//_______________

public String getCodCurso() {
	return codCurso;
}
public void setCodCurso(String codCurso) {
	this.codCurso = codCurso;
}

//_______________
}
