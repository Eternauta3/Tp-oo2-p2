package com.grupo9.gestionaulas2022.converters;

import org.springframework.stereotype.Component;
import com.grupo9.gestionaulas2022.entities.Final;
import com.grupo9.gestionaulas2022.models.FinalModel;

@Component
public class FinalConverter {
public FinalModel entityToModel(Final fin) {
return new FinalModel(fin.getId(),fin.getFecha(),fin.getTurno(),fin.getAula(),fin.getCantEstudiantes(),fin.getMateria(),fin.getObservaciones(),fin.getFechaExamen());
}
					
public Final modeltoEntity(FinalModel fin) {
return new Final(fin.getId(),fin.getFecha(),fin.getTurno(),fin.getAula(),fin.getCantEstudiantes(),fin.getMateria(),fin.getObservaciones(),fin.getFechaExamen());
}
}
