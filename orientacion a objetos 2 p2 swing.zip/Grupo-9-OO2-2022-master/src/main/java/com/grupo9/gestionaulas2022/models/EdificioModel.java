package com.grupo9.gestionaulas2022.models;

import java.util.Set;

public class EdificioModel {
//__________
	private int idedi;
	private String edificio;
	private Set<AulaModel> aulas;
//__________
public EdificioModel(String edificio) {
super();
this.setIdedi(idedi);
this.setEdificio(edificio);
this.setAulas(aulas);
}
//__________
	public int getIdedi() {
		return idedi;
	}

	protected void setIdedi(int idedi) {
		this.idedi = idedi;
	}
	public String getEdificio() {
		return edificio;
	}
	public void setEdificio(String edificio) {
		this.edificio = edificio;
	}
	public Set<AulaModel> getAulas() {
		return aulas;
	}
	public void setAulas(Set<AulaModel> aulas) {
		this.aulas = aulas;
	}
//__________
	@Override
	public String toString() {
		return "EdificioModel [idedi=" + idedi + ", edificio=" + edificio + ", aulas=" + aulas + ", getIdedi()="
				+ getIdedi() + ", getEdificio()=" + getEdificio() + ", getAulas()=" + getAulas() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString();
	}

	
}
