package com.grupo9.gestionaulas2022.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "espacio")
public class Espacio {
//__________
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private long id;

@Column(name = "fecha")
@CreationTimestamp
private LocalDateTime fecha;

@Column(name = "turno")
private char turno;

@Column(name = "aula")
private Aula aula;

@Column(name = "libre")
private boolean libre;

public Espacio() {}
//__________

public Espacio(long id, LocalDateTime fecha, char turno, Aula aula, boolean libre) {
	super();
	this.setId(id);
	this.setFecha(fecha);
	this.setTurno(turno);
	this.setAula(aula);
	this.setLibre(libre);
}

//__________

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public LocalDateTime getFecha() {
	return fecha;
}

public void setFecha(LocalDateTime fecha) {
	this.fecha = fecha;
}

public char getTurno() {
	return turno;
}

public void setTurno(char turno) {
	this.turno = turno;
}

public Aula getAula() {
	return aula;
}

public void setAula(Aula aula) {
	this.aula = aula;
}

public boolean isLibre() {
	return libre;
}

public void setLibre(boolean libre) {
	this.libre = libre;
//____________________
	
}


}
