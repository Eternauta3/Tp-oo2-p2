package com.grupo9.gestionaulas2022.converters;

import org.springframework.stereotype.Component;

import com.grupo9.gestionaulas2022.entities.Edificio;
import com.grupo9.gestionaulas2022.models.EdificioModel;

@Component
public class EdificioConverter {
	public EdificioModel entityToModel(Edificio edif) {
		return new EdificioModel(edif.getEdificio());
}
	
public Edificio modeltoEntity(EdificioModel edif) {
return new Edificio(edif.getEdificio());
	}
}
