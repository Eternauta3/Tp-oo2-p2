package com.grupo9.gestionaulas2022.converters;

import com.grupo9.gestionaulas2022.entities.Materia;
import com.grupo9.gestionaulas2022.models.MateriaModel;

public class MateriaConverter {
public MateriaModel entityToModel(Materia materia) {
return new MateriaModel(materia.getId(),materia.getCodMateria(),materia.getMateria(),materia.getCarrera());
}
	
public Materia modeltoEntity(MateriaModel materia) {
return new Materia(materia.getId(),materia.getCodMateria(),materia.getMateria(),materia.getCarrera());
}
}
