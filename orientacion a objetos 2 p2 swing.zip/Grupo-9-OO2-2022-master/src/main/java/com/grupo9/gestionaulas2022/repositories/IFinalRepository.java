package com.grupo9.gestionaulas2022.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.grupo9.gestionaulas2022.entities.Final;
@Repository
public interface IFinalRepository {
	public Final findById(long id);
	public List<Final> findAllByEnabledTrue();
	public List<Final> findAll();
}
