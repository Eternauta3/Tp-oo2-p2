package com.grupo9.gestionaulas2022.models;

import java.time.LocalDate;

import com.grupo9.gestionaulas2022.entities.Aula;
import com.grupo9.gestionaulas2022.entities.Materia;

public class FinalModel extends NotaPedidoModel{
//__________________
private LocalDate fechaExamen;
//__________________
public FinalModel(int id, LocalDate fecha, char turno, Aula aula, int cantEstudiantes, Materia materia,
		String observaciones,LocalDate fechaExamen) {
	super(id, fecha, turno, aula, cantEstudiantes, materia, observaciones);
this.setFechaExamen(fechaExamen);
}
//__________________

public LocalDate getFechaExamen() {
	return fechaExamen;
}



public void setFechaExamen(LocalDate fechaExamen) {
	this.fechaExamen = fechaExamen;
}
//__________________
}
