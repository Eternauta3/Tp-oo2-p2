package com.grupo9.gestionaulas2022.services.implementations;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupo9.gestionaulas2022.converters.UserRoleConverter;
import com.grupo9.gestionaulas2022.entities.UserRole;
import com.grupo9.gestionaulas2022.models.UserRoleModel;
import com.grupo9.gestionaulas2022.repositories.IRolRepository;
import com.grupo9.gestionaulas2022.services.IRolService;

@Service
public class RolService implements IRolService{
	@Autowired 
	private IRolRepository rolRepo;
	
	@Autowired
	private UserRoleConverter rolConverter;
	
	@Override
	public UserRole findById(long id) {
		return rolRepo.findById(id);
	}

	@Override
	public List<UserRoleModel> getAll() {
		List<UserRoleModel> roles = new ArrayList<>();
		for(UserRole rol : rolRepo.findAll()){
			roles.add(rolConverter.entityToModel(rol));
		}
		return roles;
	}
	
	@Override
	public List<UserRoleModel> getAllEnabled(int enabled) {
		List<UserRoleModel> roles = new ArrayList<>();
		for(UserRole rol : rolRepo.findAllByEnabledTrue()){
			roles.add(rolConverter.entityToModel(rol));
		}
		return roles;
	}
	
	public UserRoleModel updateRol(UserRoleModel rol) {
		UserRole role = rolRepo.save(rolConverter.modeltoEntity(rol));
		return rolConverter.entityToModel(role);
	}
}