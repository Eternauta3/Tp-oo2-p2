package com.grupo9.gestionaulas2022.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.io.Serializable;
import java.util.List;

import com.grupo9.gestionaulas2022.entities.Usuario;


@Repository
public interface IUsuarioRepository extends JpaRepository<Usuario, Serializable> {
	
	public Usuario findById(long idUsusario);
	
	public Usuario findByUsername(String Username);
	
	@Query("SELECT u FROM Usuario u JOIN FETCH u.rol WHERE u.username = (:username)")
	public abstract Usuario findByUsernameAndFetchPerfilEagerly(@Param("username") String username);
	
	public List<Usuario> findAllByEnabledTrue();
}
