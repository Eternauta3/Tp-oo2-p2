package com.grupo9.gestionaulas2022.models;

import com.grupo9.gestionaulas2022.entities.Edificio;

public class TradicionalModel extends AulaModel{

//__________
	private int cantBancos;
	private String pizarron;
	private boolean tieneProyector;
//__________
public TradicionalModel( int numero, Edificio edificio, boolean enabled, int cantBancos,String pizarron,boolean tieneProyector) {
	super(numero, edificio, enabled);
this.setCantBancos(cantBancos);
this.setPizarron(pizarron);
this.setTieneProyector(tieneProyector);
	}
//__________
public int getCantBancos() {
	return cantBancos;
}
public void setCantBancos(int cantBancos) {
	this.cantBancos = cantBancos;
}
public String getPizarron() {
	return pizarron;
}
public void setPizarron(String pizarron) {
	this.pizarron = pizarron;
}
public boolean isTieneProyector() {
	return tieneProyector;
}
public void setTieneProyector(boolean tieneProyector) {
	this.tieneProyector = tieneProyector;
}
//__________
@Override
public String toString() {
	return "TradicionalModel [cantBancos=" + cantBancos + ", pizarron=" + pizarron + ", tieneProyector="
			+ tieneProyector + "]";
}
//__________
}
