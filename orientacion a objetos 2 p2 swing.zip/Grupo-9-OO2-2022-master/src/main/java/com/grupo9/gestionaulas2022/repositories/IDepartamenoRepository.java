package com.grupo9.gestionaulas2022.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.grupo9.gestionaulas2022.entities.Departamento;

@Repository
public interface IDepartamenoRepository {
	public Departamento findById(long id);
	public List<Departamento> findAllByEnabledTrue();
	public List<Departamento> findAll();
}
