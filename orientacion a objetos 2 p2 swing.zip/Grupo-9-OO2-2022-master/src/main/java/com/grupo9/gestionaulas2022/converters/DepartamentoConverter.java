package com.grupo9.gestionaulas2022.converters;

import com.grupo9.gestionaulas2022.entities.Departamento;
import com.grupo9.gestionaulas2022.models.DepartamentoModel;

public class DepartamentoConverter {
	
public DepartamentoModel entityToModel(Departamento depar) {
return new DepartamentoModel(depar.getId(),depar.getDepartamento());
}
			
public Departamento modeltoEntity(DepartamentoModel depar) {
return new Departamento(depar.getId(),depar.getDepartamento());
}
}
