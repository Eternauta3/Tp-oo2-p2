package com.grupo9.gestionaulas2022.converters;

import org.springframework.stereotype.Component;
import com.grupo9.gestionaulas2022.entities.Curso;
import com.grupo9.gestionaulas2022.models.CursoModel;

@Component
public class CursoConverter {
public CursoModel entityToModel(Curso curso) {
return new CursoModel(curso.getId(),curso.getFecha(),curso.getTurno(),curso.getAula(),curso.getCantEstudiantes(),curso.getMateria(),curso.getObservaciones(),curso.getCodCurso());
}
			
public Curso modeltoEntity(CursoModel curso) {
return new Curso(curso.getId(),curso.getFecha(),curso.getTurno(),curso.getAula(),curso.getCantEstudiantes(),curso.getMateria(),curso.getObservaciones(),curso.getCodCurso());
}
}
