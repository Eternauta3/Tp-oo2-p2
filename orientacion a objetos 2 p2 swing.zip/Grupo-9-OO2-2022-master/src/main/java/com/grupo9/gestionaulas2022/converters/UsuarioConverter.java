package com.grupo9.gestionaulas2022.converters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.grupo9.gestionaulas2022.entities.Usuario;
import com.grupo9.gestionaulas2022.models.UsuarioModel;

@Component
public class UsuarioConverter {

	@Autowired
	private UserRoleConverter userRoleConverter;
	
	public UsuarioModel entityToModel(Usuario user) {
		return new UsuarioModel(user.getId(),user.getNombre(), user.getApellido(), user.getEmail(), user.getUsername(), user.getPassword(),user.getTipo_documento(), user.getNro_documento(),userRoleConverter.entityToModel(user.getRol()), user.isEnabled());
	}

	public Usuario modeltoEntity(UsuarioModel user) {
		return new Usuario(user.getId(),user.getNombre(), user.getApellido(), user.getEmail(), user.getUsername(), user.getPassword(),user.getTipo_documento(), user.getNro_documento(), userRoleConverter.modeltoEntity( user.getRol()),user.isEnabled());
	}
}
