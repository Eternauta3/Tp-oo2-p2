package com.grupo9.gestionaulas2022.converters;

import org.springframework.stereotype.Component;
import com.grupo9.gestionaulas2022.entities.Carrera;
import com.grupo9.gestionaulas2022.models.CarreraModel;


@Component
public class CarreraConverter {

public CarreraModel entityToModel(Carrera carrera) {
return new CarreraModel(carrera.getId(),carrera.getCarrera(),carrera.getDepartamento());
}
	
public Carrera modeltoEntity(CarreraModel carera) {
return new Carrera(carera.getId(),carera.getCarrera(),carera.getDepartamento());
}
}
