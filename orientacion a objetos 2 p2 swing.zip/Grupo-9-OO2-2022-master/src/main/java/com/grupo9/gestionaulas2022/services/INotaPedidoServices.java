package com.grupo9.gestionaulas2022.services;

import java.util.List;

import com.grupo9.gestionaulas2022.entities.NotaPedido;
import com.grupo9.gestionaulas2022.models.AulaModel;
import com.grupo9.gestionaulas2022.models.NotaPedidoModel;

public interface INotaPedidoServices {
	public List<NotaPedidoModel> getAll();
	
	public NotaPedido findById(long id);
	
	public List<NotaPedidoModel> getAllEnabled(int enabled);
		
	public NotaPedidoModel updateRol(AulaModel rol);
}
