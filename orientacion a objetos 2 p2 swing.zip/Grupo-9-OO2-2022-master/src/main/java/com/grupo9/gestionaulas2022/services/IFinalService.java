package com.grupo9.gestionaulas2022.services;

import java.util.List;

import com.grupo9.gestionaulas2022.entities.Final;
import com.grupo9.gestionaulas2022.models.AulaModel;
import com.grupo9.gestionaulas2022.models.FinalModel;

public interface IFinalService {
	public List<FinalModel> getAll();
	
	public Final findById(long id);
	
	public List<FinalModel> getAllEnabled(int enabled);
		
	public FinalModel updateRol(AulaModel rol);
}
