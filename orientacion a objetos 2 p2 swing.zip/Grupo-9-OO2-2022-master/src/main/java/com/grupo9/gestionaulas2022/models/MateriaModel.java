package com.grupo9.gestionaulas2022.models;

import com.grupo9.gestionaulas2022.entities.Carrera;

public class MateriaModel {
//__________________
private int id;
private int codMateria;
private String materia;
private Carrera carrera;
//__________________
public MateriaModel(int id, int codMateria, String materia, Carrera carrera) {
	super();
this.setId(id);
this.setCodMateria(codMateria);
this.setMateria(materia);
this.setCarrera(carrera);
}
//__________________
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getCodMateria() {
	return codMateria;
}
public void setCodMateria(int codMateria) {
	this.codMateria = codMateria;
}
public String getMateria() {
	return materia;
}
public void setMateria(String materia) {
	this.materia = materia;
}
public Carrera getCarrera() {
	return carrera;
}
public void setCarrera(Carrera carrera) {
	this.carrera = carrera;
}
//__________________
@Override
public String toString() {
	return "MateriaModel [id=" + id + ", codMateria=" + codMateria + ", materia=" + materia + ", carrera=" + carrera
			+ "]";
}
//__________________
}
