package com.grupo9.gestionaulas2022.services.implementations;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupo9.gestionaulas2022.converters.CursoConverter;
import com.grupo9.gestionaulas2022.converters.FinalConverter;
import com.grupo9.gestionaulas2022.converters.NotapedidoConverter;
import com.grupo9.gestionaulas2022.entities.Curso;
import com.grupo9.gestionaulas2022.entities.Final;
import com.grupo9.gestionaulas2022.entities.NotaPedido;
import com.grupo9.gestionaulas2022.models.CursoModel;
import com.grupo9.gestionaulas2022.models.FinalModel;
import com.grupo9.gestionaulas2022.models.NotaPedidoModel;
import com.grupo9.gestionaulas2022.repositories.ICursoRepository;
import com.grupo9.gestionaulas2022.repositories.IFinalRepository;
import com.grupo9.gestionaulas2022.repositories.INotaPedidoRepository;

@Service("notapedidoService")
public class NotaPedidoService {

@Autowired 
private INotaPedidoRepository notarepo;
@Autowired
private NotapedidoConverter notaConverter;
@Autowired 
private ICursoRepository cursorepo;
@Autowired
private CursoConverter cursoConverter;
@Autowired 
private IFinalRepository finalrepo;
@Autowired
private FinalConverter finalConverter;

public NotaPedidoModel traerNotaPedido(long id) {
NotaPedidoModel nota = notaConverter.entityToModel(notarepo.findById(id));
return nota;
}
public FinalModel traerExamenFinal(long id) {
	FinalModel curso = finalConverter.entityToModel(finalrepo.findById(id));
	return curso;
}
public CursoModel traerCurso(long id) {
CursoModel curso = cursoConverter.entityToModel(cursorepo.findById(id));
return curso;
}

public List<CursoModel> TraerCursos() {
	List<CursoModel> cursos = new ArrayList<>();
	for(Curso u : cursorepo.findAll()){
		cursos.add(cursoConverter.entityToModel(u));
	}
	return cursos;
}
public List<FinalModel> TraerExamenesFinales() {
	List<FinalModel> fin = new ArrayList<>();
	for(Final u : finalrepo.findAll()){
		fin.add(finalConverter.entityToModel(u));
	}
	return fin;
}
public List<NotaPedidoModel> TraerNotasPedido() {
	List<NotaPedidoModel> nota = new ArrayList<>();
	for(NotaPedido u : notarepo.findAll()){
		nota.add(notaConverter.entityToModel(u));
	}
	return nota;
}

}
