package com.grupo9.gestionaulas2022.models;

import java.time.LocalDate;

import com.grupo9.gestionaulas2022.entities.Aula;
import com.grupo9.gestionaulas2022.entities.Materia;

public class CursoModel extends NotaPedidoModel {
//__________________
private String codCurso;
//__________________
public CursoModel(int id, LocalDate fecha, char turno, Aula aula, int cantEstudiantes, Materia materia,
		String observaciones,String codCurso){
	super(id, fecha, turno, aula, cantEstudiantes, materia, observaciones);
this.setCodCurso(codCurso);
}
//__________________
public String getCodCurso() {
	return codCurso;
}
public void setCodCurso(String codCurso) {
	this.codCurso = codCurso;
}

//__________________
}
