package com.grupo9.gestionaulas2022.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "notapedido")
public class NotaPedido {
//________
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;
@Column(name = "fecha", unique = true, nullable = false)
private LocalDate fecha;
@Column(name = "turno")
private char turno;
@Column(name = "aula")
private Aula aula;
@Column(name = "cantestudiantes")
private int cantEstudiantes;
@Column(name = "materia")
private Materia materia;
@Column(name = "cantestudiantes")
private String observaciones;
//________
public NotaPedido(int id, LocalDate fecha, char turno, Aula aula, int cantEstuduantes, Materia materia,
		String observaciones) {
	super();
	this.setId(id);
	this.setFecha(fecha);
	this.setTurno(turno);
	this.setAula(aula);
	this.setCantEstudiantes(cantEstuduantes);
	this.setMateria(materia);
	this.setObservaciones(observaciones);
}
//________
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}
public LocalDate getFecha() {
	return fecha;
}
public void setFecha(LocalDate fecha) {
	this.fecha = fecha;
}
public char getTurno() {
	return turno;
}
public void setTurno(char turno) {
	this.turno = turno;
}
public Aula getAula() {
	return aula;
}
public void setAula(Aula aula) {
	this.aula = aula;
}
public int getCantEstudiantes() {
	return cantEstudiantes;
}
public void setCantEstudiantes(int cantEstuduantes) {
	this.cantEstudiantes = cantEstuduantes;
}
public Materia getMateria() {
	return materia;
}
public void setMateria(Materia materia) {
	this.materia = materia;
}
public String getObservaciones() {
	return observaciones;
}
public void setObservaciones(String observaciones) {
	this.observaciones = observaciones;
}
//________
@Override
public String toString() {
	return "NotaPedido [id=" + id + ", fecha=" + fecha + ", turno=" + turno + ", aula=" + aula + ", cantEstuduantes="
			+ cantEstudiantes + ", materia=" + materia + ", observaciones=" + observaciones + "]";
}
//________
}
