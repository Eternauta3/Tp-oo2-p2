package com.grupo9.gestionaulas2022.converters;

import com.grupo9.gestionaulas2022.entities.NotaPedido;
import com.grupo9.gestionaulas2022.models.NotaPedidoModel;

public class NotapedidoConverter {
public NotaPedidoModel entityToModel(NotaPedido nota) {
return new NotaPedidoModel(nota.getId(),nota.getFecha(),nota.getTurno(),nota.getAula(),nota.getCantEstudiantes(),nota.getMateria(),nota.getObservaciones());
}

public NotaPedido modeltoEntity(NotaPedidoModel nota) {
return new NotaPedido(nota.getId(),nota.getFecha(),nota.getTurno(),nota.getAula(),nota.getCantEstudiantes(),nota.getMateria(),nota.getObservaciones());
}
}
