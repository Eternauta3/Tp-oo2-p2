package com.grupo9.gestionaulas2022.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

@Entity
@Table(name = "carrera")
public class Carrera {
//________	
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;

@Column(name = "carrera", unique = true)
private String carrera;

@Column(name = "departamento", unique = true)
private Departamento departamento;
//________
public Carrera(int id, String carrera, Departamento departamento) {
	super();
	this.setId(id);
	this.setCarrera(carrera);
	this.setDepartamento(departamento);
}
//________
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}
public String getCarrera() {
	return carrera;
}
public void setCarrera(String carrera) {
	this.carrera = carrera;
}
public Departamento getDepartamento() {
	return departamento;
}
public void setDepartamento(Departamento departamento) {
	this.departamento = departamento;
}
//________
}
