package com.grupo9.gestionaulas2022.services.implementations;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.grupo9.gestionaulas2022.converters.AulaConverter;
import com.grupo9.gestionaulas2022.converters.LaboratorioConverter;
import com.grupo9.gestionaulas2022.converters.TradicionalConverter;
import com.grupo9.gestionaulas2022.entities.Aula;
import com.grupo9.gestionaulas2022.entities.Laboratorio;
import com.grupo9.gestionaulas2022.entities.Tradicional;
import com.grupo9.gestionaulas2022.models.AulaModel;
import com.grupo9.gestionaulas2022.models.LaboratorioModel;
import com.grupo9.gestionaulas2022.models.TradicionalModel;
import com.grupo9.gestionaulas2022.repositories.IAulaRepository;
import com.grupo9.gestionaulas2022.repositories.ILaboratorioRepository;
import com.grupo9.gestionaulas2022.repositories.ITradicionalRepository;

@Service("aulaService")
public class AulaService {
@Autowired 
private IAulaRepository aulaRepo;
@Autowired 
private ILaboratorioRepository laboratorioRepo;
@Autowired 
private ITradicionalRepository tradicionalRepo;
@Autowired
private AulaConverter aulaConverter;
@Autowired
private LaboratorioConverter laboConverter;
@Autowired
private TradicionalConverter tradConverter;

public AulaModel traerAula(long id) {
	AulaModel aula = aulaConverter.entityToModel(aulaRepo.findById(id));
	return aula;
}

public LaboratorioModel traerLaboratorio(long id) {
	LaboratorioModel laboratorio = laboConverter.entityToModel(laboratorioRepo.findById(id));
	return laboratorio;
}

public TradicionalModel traerTradicional(long id) {
	TradicionalModel laboratorio = tradConverter.entityToModel(tradicionalRepo.findById(id));
	return laboratorio;
}

public List<AulaModel> TraerAulas() {
	List<AulaModel> aulas = new ArrayList<>();
	for(Aula u : aulaRepo.findAll()){
		aulas.add(aulaConverter.entityToModel(u));
	}
	return aulas;
}

public List<LaboratorioModel> TraerLaboratorios() {
	List<LaboratorioModel> laboratorios = new ArrayList<>();
	for(Laboratorio u : laboratorioRepo.findAll()){
		laboratorios.add(laboConverter.entityToModel(u));
	}
	return laboratorios;
}

public List<TradicionalModel> TraerTradicionales() {
	List<TradicionalModel> tradicionales = new ArrayList<>();
	for(Tradicional u : tradicionalRepo.findAll()){
		tradicionales.add(tradConverter.entityToModel(u));
	}
	return tradicionales;
}
}
