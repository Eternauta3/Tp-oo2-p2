package com.grupo9.gestionaulas2022.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.grupo9.gestionaulas2022.entities.Curso;

@Repository
public interface ICursoRepository {
	public Curso findById(long id);
	public List<Curso> findAllByEnabledTrue();
	public List<Curso> findAll();
}
