package com.grupo9.gestionaulas2022.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "laboratorio")
public class Laboratorio extends Aula{
//________________________________________________
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;

@Column(name = "numero", unique = true, nullable = false)
private int numero;

@Column(name = "edificio", nullable = false)
private Edificio edificio;

@Column(name = "enabled")
private boolean enabled;

@Column(name = "cantpc", nullable = false)
private int cantPc;

@Column(name = "cantsillas")
private int cantSillas;

public Laboratorio(){}
//________________________________________________
public Laboratorio(int numero, Edificio edificio, boolean enabled,int cantPc,int cantSillas) {
	super(numero, edificio, enabled);
this.setCantPc(cantPc);
this.setCantSillas(cantSillas);
}
//________________________________________________

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public int getNumero() {
	return numero;
}

public void setNumero(int numero) {
	this.numero = numero;
}

public Edificio getEdificio() {
	return edificio;
}

public void setEdificio(Edificio edificio) {
	this.edificio = edificio;
}

public boolean isEnabled() {
	return enabled;
}

public void setEnabled(boolean enabled) {
	this.enabled = enabled;
}

public int getCantPc() {
	return cantPc;
}

public void setCantPc(int cantPc) {
	this.cantPc = cantPc;
}

public int getCantSillas() {
	return cantSillas;
}

public void setCantSillas(int cantSillas) {
	this.cantSillas = cantSillas;
//________________________________________________
}
}
