package com.grupo9.gestionaulas2022.repositories;

import java.util.List;

import com.grupo9.gestionaulas2022.entities.Carrera;

public interface ICarreraRepository {
	public Carrera findById(long id);
	public List<Carrera> findAllByEnabledTrue();
	public List<Carrera> findAll();
}
