package com.grupo9.gestionaulas2022.services;

import java.util.List;

import com.grupo9.gestionaulas2022.entities.Tradicional;
import com.grupo9.gestionaulas2022.models.TradicionalModel;

public interface ITradicionalService {
	
	public Tradicional findById(long id);
	
	public List<TradicionalModel> getAllEnabled(int enabled);
		
	public TradicionalModel updateRol(TradicionalModel rol);
}
