package com.grupo9.gestionaulas2022.converters;

import com.grupo9.gestionaulas2022.entities.Tradicional;
import com.grupo9.gestionaulas2022.models.TradicionalModel;

public class TradicionalConverter {
public TradicionalModel entityToModel(Tradicional trad) {
return new TradicionalModel(trad.getNumero(),trad.getEdificio(),trad.isEnabled(),trad.getCantBancos(),trad.getPizarron(),trad.isTieneProyector());
}

public Tradicional modeltoEntity(TradicionalModel trad) {
return new Tradicional(trad.getNumero(),trad.getEdificio(),trad.isEnabled(),trad.getCantBancos(),trad.getPizarron(),trad.isTieneProyector());
}
}