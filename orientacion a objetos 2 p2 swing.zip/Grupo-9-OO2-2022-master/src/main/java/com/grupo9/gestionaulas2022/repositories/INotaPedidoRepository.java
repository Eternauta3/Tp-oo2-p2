package com.grupo9.gestionaulas2022.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.grupo9.gestionaulas2022.entities.NotaPedido;

@Repository
public interface INotaPedidoRepository {
	public NotaPedido findById(long id);
	public List<NotaPedido> findAllByEnabledTrue();
	public List<NotaPedido> findAll();
}
