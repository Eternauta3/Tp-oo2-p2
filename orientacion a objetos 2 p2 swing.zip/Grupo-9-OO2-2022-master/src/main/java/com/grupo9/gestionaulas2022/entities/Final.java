package com.grupo9.gestionaulas2022.entities;

import java.time.LocalDate;

import javax.persistence.Column;

public class Final extends NotaPedido{
//________
	@Column(name = "carrera", unique = true)
	private LocalDate fechaExamen;
//________
public Final(int id, LocalDate fecha, char turno, Aula aula, int cantEstuduantes, Materia materia,
	String observaciones,LocalDate fechaExamen) {
super(id, fecha, turno, aula, cantEstuduantes, materia, observaciones);
this.setFechaeExamen(fechaExamen);
}

//________
public LocalDate getFechaExamen() {
	return fechaExamen;
}

public void setFechaeExamen(LocalDate fechaeExamen) {
	this.fechaExamen = fechaeExamen;
}
//________

@Override
public String toString() {
	return "Final [toString()=" + super.toString() + ", fechaExamen=" + fechaExamen + "]";
}
//________
}
