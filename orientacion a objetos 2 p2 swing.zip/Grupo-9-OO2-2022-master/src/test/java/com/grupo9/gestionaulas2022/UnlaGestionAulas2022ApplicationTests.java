package com.grupo9.gestionaulas2022;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnlaGestionAulas2022ApplicationTests {

	@Test
	void contextLoads() {
	}

}
